# Podcast Claw Skill

OpenClaw Skill for converting web articles and text content into audio podcasts.

## Features

- Extract content from URLs or local files
- Generate podcast scripts using AI (single-host narration style)
- Synthesize speech using Edge TTS (free, good Chinese support)
- Output MP3 audio files

## Installation

1. Copy this skill to your OpenClaw skills directory:
```bash
cp -r podcast-claw-skill ~/.openclaw/skills/
```

2. Run the environment check:
```bash
~/.openclaw/skills/podcast-claw-skill/scripts/check-and-install.sh
```

3. Configure API keys:
```bash
mkdir -p ~/.podcastfy
cat > ~/.podcastfy/.env << 'ENV'
OPENROUTER_API_KEY=sk-or-v1-your-key-here
ENV
```

## Usage

```bash
~/.openclaw/skills/podcast-claw-skill/scripts/generate-podcast.sh "https://example.com/article"
```

Output files:
- `podcast_transcript.txt` - Podcast script
- `podcast_transcript.mp3` - Audio file

## Requirements

- Python 3.8+
- OpenRouter API Key (or OpenAI/Gemini)
- Edge TTS (automatically installed)

## License

MIT
