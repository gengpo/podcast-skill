#!/bin/bash
# 生成单主播播客

set -e

if [ -z "$1" ]; then
    echo "用法: $0 <文章URL或文件路径>"
    exit 1
fi

INPUT="$1"
export PATH="$HOME/.local/bin:$PATH"
export PODCAST_INPUT="$INPUT"

echo "🎙️  正在生成播客..."
echo "   输入: $INPUT"

python3 << 'PYTHON'
import os
import sys
import urllib.request

sys.path.insert(0, os.path.expanduser("~/.local/lib/python3.12/site-packages"))
from openai import OpenAI

def fetch_url(url):
    jina_url = f"https://r.jina.ai/http://{url.replace('https://', '').replace('http://', '')}"
    req = urllib.request.Request(jina_url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=30) as response:
        return response.read().decode('utf-8')

input_source = os.environ.get('PODCAST_INPUT', '')

if input_source.startswith('http'):
    print("📥 正在获取 URL 内容...")
    content = fetch_url(input_source)
else:
    print(f"📖 读取文件: {input_source}")
    with open(input_source, 'r', encoding='utf-8') as f:
        content = f.read()

print(f"📄 内容长度: {len(content)} 字符")

if len(content) > 12000:
    content = content[:12000] + "\n...[内容已截断]"
    print("⚠️  内容过长，已截断")

print("🤖 正在生成播客脚本...")

api_key = os.environ.get("OPENROUTER_API_KEY") or os.environ.get("OPENAI_API_KEY")
if api_key and api_key.startswith("sk-or-"):
    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key)
    model = "openai/gpt-4o"
else:
    client = OpenAI(api_key=api_key)
    model = "gpt-4o"

response = client.chat.completions.create(
    model=model,
    messages=[
        {"role": "system", "content": "你是一位专业的播客主播。请将以下内容转换为单人讲述形式的播客脚本，风格亲切自然，像在对听众讲故事一样。"},
        {"role": "user", "content": f"请将以下文章转换为单主播播客脚本（中文）：\n\n{content}"}
    ],
    temperature=0.7,
    max_tokens=4000
)

transcript = response.choices[0].message.content

with open("podcast_transcript.txt", "w", encoding="utf-8") as f:
    f.write(transcript)

print(f"✅ 脚本已保存")
print(f"\n📝 预览:\n{transcript[:300]}...")

print("\n🔊 生成音频...")
try:
    import asyncio
    import edge_tts
    
    async def gen():
        await edge_tts.Communicate(transcript, "zh-CN-XiaoxiaoNeural").save("podcast_transcript.mp3")
    
    asyncio.run(gen())
    print(f"✅ 音频已保存: podcast_transcript.mp3")
except Exception as e:
    print(f"⚠️  音频失败: {e}")

PYTHON

echo ""
echo "🎉 完成！"
